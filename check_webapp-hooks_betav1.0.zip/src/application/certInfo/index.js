import React from 'react';

function CertInfo(){
    return(
        <div>
            <h1>合同明细</h1>
        </div>
    )
}

export default CertInfo;