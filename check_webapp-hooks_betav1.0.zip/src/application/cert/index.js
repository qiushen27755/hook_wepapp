import React from 'react';

function Cert(){
    return(
        <div>
            <h1> 没有合同 </h1>
        </div>
    )
}
export default Cert